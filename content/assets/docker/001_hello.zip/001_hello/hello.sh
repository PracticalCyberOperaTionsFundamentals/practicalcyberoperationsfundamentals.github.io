#!/usr/bin/env bash

/usr/games/cowsay "Hello, $FLAG!"
